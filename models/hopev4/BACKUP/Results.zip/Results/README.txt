B_experiments
varia il budget, fissi la random pool size(20%) e il numero di veicoli(120)

RS_experiments
varia la random pool size, fissi il budget iniziale(100) e il numero di veicoli(120)

VS_experiments
varia il numero di veicoli, fissi il budget iniziale(100) e la random pool size(20%)
