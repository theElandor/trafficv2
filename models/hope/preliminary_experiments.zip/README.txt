Esperimenti preliminari (descritti più nel dettaglio nella tesi)

-------------------
Il modello è stato ALLENATO con:
- 120 veicoli
- B = 0.1 (i veicoli sponsorizzano casualmente tra lo 0 e il 10% del budget)
- Tutti i veicoli hanno la stessa velocità massima(pari a 4)
- Budget iniziale (ricaricato ad ogni reroute) pari a 100 per tutti i veicoli,
  compreso quello di test 
------------------

Il modello è stato TESTATO con:
- numero di veicoli variabile
- budget iniziale costante
- B costante
- Velocità costante


PS: ho anche fatto lo stesso tipo di test ma con il parametro B
	pari a 0.2, se serve mando anche quei grafici.
